
  








/*function myFunction1() { 
	document.getElementById("first1").style.display="none"; 
	document.getElementById("second1").style.display="block"; 
}

function myFunction() { 
	document.getElementById("first").style.display="none"; 
	document.getElementById("second").style.display="block"; 
}*/



